define({
  _widgetLabel: 'Карта',
  _action_displayFeatureSet_label: 'Отобразить набор объектов',
  _action_panTo_label: 'Переместить к',
  _action_zoomToFeature_label: 'Приблизить к',
  _action_selectFeature_label: 'Выбрать объект',
  _action_flash_label: 'Подсветить',
  _action_filter_label: 'Фильтр'
});