define({
  _widgetLabel: 'מפה',
  _action_displayFeatureSet_label: 'הצג סט ישויות',
  _action_panTo_label: 'עבור אל',
  _action_zoomToFeature_label: 'התמקדות',
  _action_selectFeature_label: 'בחר ישות',
  _action_flash_label: 'הבהוב',
  _action_filter_label: 'מסנן'
});