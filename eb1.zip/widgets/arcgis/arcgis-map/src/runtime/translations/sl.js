define({
  _widgetLabel: 'Karta',
  _action_displayFeatureSet_label: 'Prikaži sklop geoobjektov',
  _action_panTo_label: 'Pomakni na',
  _action_zoomToFeature_label: 'Povečaj na',
  _action_selectFeature_label: 'Izberi geoobjekt',
  _action_flash_label: 'Osvetli',
  _action_filter_label: 'Filtriraj'
});