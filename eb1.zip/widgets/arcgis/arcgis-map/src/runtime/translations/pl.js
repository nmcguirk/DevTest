define({
  _widgetLabel: 'Mapa',
  _action_displayFeatureSet_label: 'Wyświetl zestaw obiektów',
  _action_panTo_label: 'Przesuń do',
  _action_zoomToFeature_label: 'Powiększ do',
  _action_selectFeature_label: 'Wybierz obiekt',
  _action_flash_label: 'Podświetlenie',
  _action_filter_label: 'Filtr'
});