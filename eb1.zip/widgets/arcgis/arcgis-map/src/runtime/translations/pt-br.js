define({
  _widgetLabel: 'Mapa',
  _action_displayFeatureSet_label: 'Exibir conjunto de feição',
  _action_panTo_label: 'Mover para',
  _action_zoomToFeature_label: 'Zoom para',
  _action_selectFeature_label: 'Selecionar feição',
  _action_flash_label: 'Destacar',
  _action_filter_label: 'Filtrar'
});