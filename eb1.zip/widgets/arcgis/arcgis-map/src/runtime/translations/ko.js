define({
  _widgetLabel: '맵',
  _action_displayFeatureSet_label: '피처 모음 보기',
  _action_panTo_label: '이동',
  _action_zoomToFeature_label: '확대',
  _action_selectFeature_label: '피처 선택',
  _action_flash_label: '깜박이기',
  _action_filter_label: '필터'
});