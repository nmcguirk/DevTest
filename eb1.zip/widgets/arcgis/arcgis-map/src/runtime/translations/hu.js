define({
  _widgetLabel: 'Térkép',
  _action_displayFeatureSet_label: 'Vektoroselem-készlet megjelenítése',
  _action_panTo_label: 'Mozgatás',
  _action_zoomToFeature_label: 'Nagyítás erre:',
  _action_selectFeature_label: 'Vektoros elem kijelölése',
  _action_flash_label: 'Felvillant',
  _action_filter_label: 'Szűrő'
});