define({
  _widgetLabel: 'Žemėlapis',
  _action_displayFeatureSet_label: 'Rodyti elementų rinkinį',
  _action_panTo_label: 'Pereiti į',
  _action_zoomToFeature_label: 'Pritraukti iki',
  _action_selectFeature_label: 'Pasirinkti elementą',
  _action_flash_label: 'Blykčioti',
  _action_filter_label: 'Filtruoti'
});