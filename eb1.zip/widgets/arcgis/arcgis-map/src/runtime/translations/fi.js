define({
  _widgetLabel: 'Kartta',
  _action_displayFeatureSet_label: 'Näytä kohdejoukko',
  _action_panTo_label: 'Vieritä kohteeseen',
  _action_zoomToFeature_label: 'Tarkenna kohteeseen',
  _action_selectFeature_label: 'Valitse kohde',
  _action_flash_label: 'Flash',
  _action_filter_label: 'Suodata'
});