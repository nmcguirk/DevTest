define({
  _widgetLabel: 'Mapa',
  _action_displayFeatureSet_label: 'Mostrar conjunto de entidades',
  _action_panTo_label: 'Desplazar a',
  _action_zoomToFeature_label: 'Acercar a',
  _action_selectFeature_label: 'Seleccionar entidad',
  _action_flash_label: 'Destacar',
  _action_filter_label: 'Filtrar'
});