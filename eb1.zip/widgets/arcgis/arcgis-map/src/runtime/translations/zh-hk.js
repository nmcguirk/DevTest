define({
  _widgetLabel: '地圖',
  _action_displayFeatureSet_label: '顯示圖徵集',
  _action_panTo_label: '平移至',
  _action_zoomToFeature_label: '縮放至',
  _action_selectFeature_label: '選擇圖徵',
  _action_flash_label: '閃爍',
  _action_filter_label: '篩選'
});