define({
  _widgetLabel: 'Mapa',
  _action_displayFeatureSet_label: 'Mostra el conjunt d\'entitats',
  _action_panTo_label: 'Desplaça panoràmicament a',
  _action_zoomToFeature_label: 'Aplica el zoom a',
  _action_selectFeature_label: 'Seleccioneu una entitat',
  _action_flash_label: 'Destaca',
  _action_filter_label: 'Filtra'
});