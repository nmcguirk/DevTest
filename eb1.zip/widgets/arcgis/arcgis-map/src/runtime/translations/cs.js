define({
  _widgetLabel: 'Mapa',
  _action_displayFeatureSet_label: 'Sada prvků zobrazení',
  _action_panTo_label: 'Posunout k',
  _action_zoomToFeature_label: 'Zvětšit na',
  _action_selectFeature_label: 'Vyberte prvek',
  _action_flash_label: 'Zablikat',
  _action_filter_label: 'Filtr'
});