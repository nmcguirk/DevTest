define({
  _widgetLabel: 'Kart',
  _action_displayFeatureSet_label: 'Vis geoobjektsett',
  _action_panTo_label: 'Panorer til',
  _action_zoomToFeature_label: 'Zoom til',
  _action_selectFeature_label: 'Velg geoobjekt',
  _action_flash_label: 'Flash',
  _action_filter_label: 'Filter'
});