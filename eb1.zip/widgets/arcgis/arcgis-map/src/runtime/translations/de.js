define({
  _widgetLabel: 'Karte',
  _action_displayFeatureSet_label: 'Feature-Set anzeigen',
  _action_panTo_label: 'Schwenken auf',
  _action_zoomToFeature_label: 'Zoomen auf',
  _action_selectFeature_label: 'Feature auswählen',
  _action_flash_label: 'Position aufblinken lassen',
  _action_filter_label: 'Filtern'
});