define({
  _widgetLabel: 'Mapa',
  _action_displayFeatureSet_label: 'Exibir conjunto de elementos',
  _action_panTo_label: 'Mover para',
  _action_zoomToFeature_label: 'Efetuar zoom para',
  _action_selectFeature_label: 'Selecionar elemento',
  _action_flash_label: 'Flash',
  _action_filter_label: 'Filtro'
});