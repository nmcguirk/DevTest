define({
  _widgetLabel: 'Karte',
  _action_displayFeatureSet_label: 'Parādīt elementu kopu',
  _action_panTo_label: 'Pārbīdīt uz',
  _action_zoomToFeature_label: 'Tālummaiņa',
  _action_selectFeature_label: 'Atlasīt elementu',
  _action_flash_label: 'Flash',
  _action_filter_label: 'Filtrs'
});