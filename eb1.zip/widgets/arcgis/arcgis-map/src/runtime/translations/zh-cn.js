define({
  _widgetLabel: '地图',
  _action_displayFeatureSet_label: '显示要素集',
  _action_panTo_label: '平移至',
  _action_zoomToFeature_label: '缩放至',
  _action_selectFeature_label: '选择要素',
  _action_flash_label: '闪烁',
  _action_filter_label: '过滤器'
});