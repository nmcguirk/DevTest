define({
  _widgetLabel: 'Mapa',
  _action_displayFeatureSet_label: 'Set za prikaz funkcija',
  _action_panTo_label: 'Pomeri do',
  _action_zoomToFeature_label: 'Zumiraj na',
  _action_selectFeature_label: 'Izaberite geoobjekat',
  _action_flash_label: 'Blic',
  _action_filter_label: 'Filter'
});