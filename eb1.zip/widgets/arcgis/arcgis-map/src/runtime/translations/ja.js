define({
  _widgetLabel: 'マップ',
  _action_displayFeatureSet_label: 'フィーチャ セットの表示',
  _action_panTo_label: '画面移動',
  _action_zoomToFeature_label: 'ズーム',
  _action_selectFeature_label: 'フィーチャの選択',
  _action_flash_label: 'フラッシュ',
  _action_filter_label: 'フィルター'
});