define({
  _widgetLabel: 'Карта',
  _action_displayFeatureSet_label: 'Відображати набір функцій',
  _action_panTo_label: 'Перемістити до',
  _action_zoomToFeature_label: 'Масштабувати до',
  _action_selectFeature_label: 'Вибрати об’єкт',
  _action_flash_label: 'Підсвітити',
  _action_filter_label: 'Фільтр'
});